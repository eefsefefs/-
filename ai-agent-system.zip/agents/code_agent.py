def generate_code(req):
    return f"""
def hello():
    return "Hello World"
# based on: {req}
"""
