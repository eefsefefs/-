def generate_test(code):
    return f"""
def test_hello():
    assert hello() == "Hello World"
"""
