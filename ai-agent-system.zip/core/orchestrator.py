from agents.requirement_agent import analyze_requirement
from agents.code_agent import generate_code
from agents.test_agent import generate_test
from agents.review_agent import review_code

def run_pipeline(user_input):
    print("🧠 Requirement Agent...")
    req = analyze_requirement(user_input)

    print("💻 Code Agent...")
    code = generate_code(req)

    print("🧪 Test Agent...")
    test = generate_test(code)

    print("🔍 Review Agent...")
    review = review_code(code)

    return {
        "requirement": req,
        "code": code,
        "test": test,
        "review": review
    }
