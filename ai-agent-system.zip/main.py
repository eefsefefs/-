from fastapi import FastAPI
from core.orchestrator import run_pipeline

app = FastAPI()

@app.get("/")
def root():
    return {"msg": "AI Agent System Running"}

@app.get("/run")
def run_task(q: str):
    result = run_pipeline(q)
    return {"result": result}
